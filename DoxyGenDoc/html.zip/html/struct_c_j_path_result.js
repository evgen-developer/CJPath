var struct_c_j_path_result =
[
    [ "strLen", "struct_c_j_path_result.html#a19cd380f667b2c20ca0e35c73d962501", null ],
    [ "strPtr", "struct_c_j_path_result.html#ac7ce21ccac18b760c6038b0396b1217b", null ]
];