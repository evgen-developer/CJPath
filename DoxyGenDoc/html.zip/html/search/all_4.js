var searchData=
[
  ['memallocfunc_0',['MemAllocFunc',['../_c_j_path_8h.html#a0e14796d6f73667ae833f539f4277b60',1,'CJPath.h']]],
  ['memfreefunc_1',['MemFreeFunc',['../_c_j_path_8h.html#aa40a05070c9b4f2bc044c1188cdf227c',1,'CJPath.h']]]
];
