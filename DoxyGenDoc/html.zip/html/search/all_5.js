var searchData=
[
  ['next_0',['next',['../struct___c_j_path_list.html#a83825ba0aae4c3f89abeae9e8099636f',1,'_CJPathList']]],
  ['not_5ffound_1',['NOT_FOUND',['../_c_j_path_8h.html#afe5cb061407cd34dceaf5fafc5a4b23cacdaa2919bac56fe1090eb3dbb9526472',1,'CJPath.h']]]
];
