var searchData=
[
  ['cjpathlist_0',['CJPathList',['../_c_j_path_8h.html#a82b615333fcbfdef817069b1cd3d0fe6',1,'CJPath.h']]],
  ['cjpathstatus_1',['CJPathStatus',['../_c_j_path_8h.html#a39104c3fe98b7bd20620be681a1df281',1,'CJPath.h']]]
];
