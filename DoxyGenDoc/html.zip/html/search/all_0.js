var searchData=
[
  ['_5fcjpathlist_0',['_CJPathList',['../struct___c_j_path_list.html',1,'']]],
  ['_5fcjpathstatus_1',['_CJPathStatus',['../_c_j_path_8h.html#afe5cb061407cd34dceaf5fafc5a4b23c',1,'CJPath.h']]]
];
