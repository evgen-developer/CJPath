var searchData=
[
  ['result_0',['result',['../struct___c_j_path_list.html#a7b05956a4c05da4234b78dfd3ebc5e26',1,'_CJPathList']]]
];
