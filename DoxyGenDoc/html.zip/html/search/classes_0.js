var searchData=
[
  ['_5fcjpathlist_0',['_CJPathList',['../struct___c_j_path_list.html',1,'']]]
];
