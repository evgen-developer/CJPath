var searchData=
[
  ['next_0',['next',['../struct___c_j_path_list.html#a83825ba0aae4c3f89abeae9e8099636f',1,'_CJPathList']]]
];
