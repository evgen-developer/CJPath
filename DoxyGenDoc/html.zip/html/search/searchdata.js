var indexSectionsWithContent =
{
  0: "_bcimnprs",
  1: "_c",
  2: "c",
  3: "c",
  4: "nprs",
  5: "cm",
  6: "_",
  7: "bins",
  8: "c",
  9: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

