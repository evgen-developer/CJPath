var searchData=
[
  ['cjpathresult_0',['CJPathResult',['../struct_c_j_path_result.html',1,'']]]
];
