var struct___c_j_path_list =
[
    [ "next", "struct___c_j_path_list.html#a83825ba0aae4c3f89abeae9e8099636f", null ],
    [ "prev", "struct___c_j_path_list.html#a6295ee1612f3150943905ada783f459d", null ],
    [ "result", "struct___c_j_path_list.html#a7b05956a4c05da4234b78dfd3ebc5e26", null ]
];